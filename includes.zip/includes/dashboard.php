<div align="center" style="padding:50px 0 120px 0; height:450px; width:900px;" >

    <div class="box"><a href="<?php echo ADMINURLPATH.'category_manage&p=0';?>" title="Inventory"><img src="images/admin/inventory.png" alt="Home" /><br /><span class="home-link">INVENTORY</span></a></div>
    
<!--    <div class="box"><a href="--><?php //echo ADMINURLPATH; ?><!--product_manage&p=0" title="MANAGE PRODUCTS"><img src="images/admin/product.png" alt="PRODUCTS" /><br />PRODUCTS</a></div>-->
    
    <div class="box"><a href="<?php echo ADMINURLPATH; ?>change_password" title="CHANGE PASSWORD"><img src="images/admin/config.png" alt="Change Password" /><br />CHANGE PASSWORD</a></div>
    
<!--    <div class="box"><a href="--><?php //echo ADMINURLPATH; ?><!--salesView" title="MAKE SALE"><img src="images/admin/sale.png" alt="SALE" /><br />SALE</a></div>-->
    
    <div class="box"><a href="<?php echo ADMINURLPATH; ?>salesView" title="REPORT"><img src="images/admin/report.png" alt="Report" /><br />REPORT</a></div>
</div>